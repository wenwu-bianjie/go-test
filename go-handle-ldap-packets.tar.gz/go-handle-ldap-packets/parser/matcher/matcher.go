package matcher

import (
	"go-handle-ldap-packets/logger"
	"go-handle-ldap-packets/util"
	"log"
	"regexp"
)

type Matcher struct {
	regs []*regexp.Regexp
}

func NewMatcher(s string) *Matcher {
	var (
		keys []string
		regs []*regexp.Regexp
		mStr string
	)
	if util.Trim(s) != "" {
		keys = util.StringsSplit(s, ",")
	}
	for _, key := range keys {
		mStr = util.Trim(key)
		if mStr == "" {
			continue
		}
		if reg, err := regexp.Compile(mStr); err != nil {
			// 出错报错并退出程序
			logger.Error.Printf("create regexp by %s with error: %s", mStr, err)
			log.Fatalf("create regexp by %s with error: %s", mStr, err)
		} else {
			regs = append(regs, reg)
		}
	}
	return &Matcher{regs: regs}
}

func (m *Matcher) Match(payload []byte) bool {
	for _, reg := range m.regs {
		if reg.Match(payload) {
			return true
		}
	}
	return false
}
