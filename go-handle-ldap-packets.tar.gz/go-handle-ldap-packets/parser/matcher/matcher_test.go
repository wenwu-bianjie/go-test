package matcher

import (
	"fmt"
	"testing"
)

func TestNewMatcher(t *testing.T) {
	matcher := NewMatcher("uid=jingb48,ou=0803010000")
	s := "uid=jingb48,ou=0803010000"
	res := matcher.Match([]byte(s))
	fmt.Println(res)
}
