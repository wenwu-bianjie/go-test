package analyzer

import (
	"github.com/google/gopacket"
	"github.com/google/gopacket/layers"
	"github.com/google/gopacket/pcap"
	"go-handle-ldap-packets/config"
	"go-handle-ldap-packets/logger"
	"go-handle-ldap-packets/parser/matcher"
	"io"
	"net"
	"strings"
	"syscall"
)

// 解析的报文协议
var (
	eth     layers.Ethernet
	ip4     layers.IPv4
	ip6     layers.IPv6
	tcp     layers.TCP
	payload gopacket.Payload
)

// 自定义报文解析器
var parser *gopacket.DecodingLayerParser = gopacket.NewDecodingLayerParser(layers.LayerTypeEthernet, &eth, &ip4, &ip6, &tcp, &payload)

// 报文解析存储的slice
var decodedLayers []gopacket.LayerType = make([]gopacket.LayerType, 0, 5)

type handler struct {
	fileName string
	handle   *pcap.Handle
	matcher  *matcher.Matcher
}

// 单例解析对象
var singeHandler *handler

func newHandle(pcapFile string) (*handler, error) {
	var (
		handle *pcap.Handle
		err    error
		m      *matcher.Matcher
	)
	if handle, err = pcap.OpenOffline(pcapFile); err != nil {
		return nil, err
	}
	// 单例模式
	if singeHandler != nil {
		singeHandler.handle = handle
		singeHandler.fileName = pcapFile
		return singeHandler, nil
	}
	// 创建匹配器
	m = matcher.NewMatcher(config.G_config.MatchFields)
	singeHandler = &handler{
		handle:   handle,
		matcher:  m,
		fileName: pcapFile,
	}
	return singeHandler, nil
}

func (h *handler) handlePacket() bool {
	var (
		data      []byte
		err       error
		isMatched bool
		matched   bool
		netErr    net.Error
		ok        bool
	)
	for {
		data, _, err = h.handle.ReadPacketData()
		if err == nil {
			if matched, err = h.decodeLayers(data); err == nil {
				// 判断是否匹配到指定的字段
				if matched {
					isMatched = matched
				}
			} else {
				logger.Error.Printf("decode packets : %s with error: %s", data, err)
			}
			continue
		}
		// Immediately retry for temporary network errors
		if netErr, ok = err.(net.Error); ok && netErr.Temporary() {
			continue
		}
		// Immediately retry for EAGAIN
		if err == syscall.EAGAIN {
			continue
		}
		// Immediately break for known unrecoverable errors
		if err == io.EOF || err == io.ErrUnexpectedEOF ||
			err == io.ErrNoProgress || err == io.ErrClosedPipe || err == io.ErrShortBuffer ||
			err == syscall.EBADF ||
			strings.Contains(err.Error(), "use of closed file") {
			break
		}
	}
	return isMatched
}

func (h *handler) decodeLayers(data []byte) (bool, error) {
	var (
		err       error
		isMatched bool
		layer     gopacket.LayerType
	)
	if err = parser.DecodeLayers(data, &decodedLayers); err != nil {
		return isMatched, err
	}
	for _, layer = range decodedLayers {
		switch layer {
		case layers.LayerTypeTCP:
			if h.matcher.Match(tcp.Payload) {
				logger.Info.Printf("matched file: %s, the tcp payload: %s", h.fileName, tcp.Payload)
				isMatched = true
			}
		}
	}
	return isMatched, nil
}
