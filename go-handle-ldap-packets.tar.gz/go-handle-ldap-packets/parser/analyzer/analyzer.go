package analyzer

import (
	"go-handle-ldap-packets/logger"
	"go-handle-ldap-packets/model"
)

type Analyzer struct {
	fileChan         chan string // 需要解析文件的通道
	fileParseResChan chan *model.FileParseRes
	handle           *handler
	parseFiles       []string    // 正在解析或者准备解析的报文文件
	fileMovedChan    chan string // 已经解析完成完成转移的文件
}

func NewAnalyzer() *Analyzer {
	return &Analyzer{
		fileChan:         make(chan string, 100),
		fileParseResChan: make(chan *model.FileParseRes, 100),
		parseFiles:       make([]string, 0, 100),
		fileMovedChan:    make(chan string, 100),
	}
}

func (a *Analyzer) Run() {
	// 启动解析goroutine
	go a.parse()
}

func (a *Analyzer) parse() {
	var (
		err       error
		isMatched bool
	)
	for {
		select {
		case file := <-a.fileChan:
			var skip = false
			// 如果已经正在解析或者解析过的文件，将直接跳出解析流程
			for _, parseFile := range a.parseFiles {
				if parseFile == file {
					skip = true
					break
				}
			}
			// 跳过当前文件解析
			if skip {
				break
			}
			a.parseFiles = append(a.parseFiles, file)
			if a.handle, err = newHandle(file); err != nil {
				logger.Error.Printf("create %s handle with error: %s", file, err)
				continue
			} else {
				// 处理报文数据
				isMatched = a.handle.handlePacket()
				a.handle.handle.Close()
				logger.Info.Printf("result of parse file: %s, is matched: %v", file, isMatched)
				a.fileParseResChan <- &model.FileParseRes{
					FileName:  file,
					IsMatched: isMatched,
				}
			}
		case movedFile := <-a.fileMovedChan:
			for i, file := range a.parseFiles {
				if file == movedFile {
					a.parseFiles = append(a.parseFiles[:i], a.parseFiles[i+1:]...)
				}
			}
		}
	}
}

func (a *Analyzer) GetFileChan() chan string {
	return a.fileChan
}

func (a *Analyzer) GetFileMovedChan() chan string {
	return a.fileMovedChan
}

func (a *Analyzer) GetFileParseResChan() chan *model.FileParseRes {
	return a.fileParseResChan
}

func (a *Analyzer) Close() {
	if a.handle != nil {
		if a.handle.handle != nil {
			a.handle.handle.Close()
		}
	}
}
