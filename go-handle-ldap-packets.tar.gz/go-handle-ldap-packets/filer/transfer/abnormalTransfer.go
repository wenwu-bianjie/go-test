package transfer

import (
	"errors"
	"fmt"
	"go-handle-ldap-packets/logger"
	"go-handle-ldap-packets/util"
)

type AbnormalTransfer struct {
	distDir string
}

func NewAbnormalTransfer(disDir string) (*AbnormalTransfer, error) {
	var (
		dir string
		err error
	)
	if disDir == "" {
		return nil, errors.New("abnormal_dir can not be empty")
	}
	dir = util.ReplacePathSeparator(disDir)
	err = util.CreateDir(dir)
	if err != nil {
		return nil, fmt.Errorf("create abnormal_dir with error: %s", err)
	}
	return &AbnormalTransfer{
		distDir: dir,
	}, nil
}

func (t *AbnormalTransfer) Move(src string) error {
	var (
		fileName string
		dist     string
		err      error
	)
	if fileName, err = util.PathToFileName(src); err != nil {
		return err
	}
	dist = util.ComputeFilePath(t.distDir, fileName)
	logger.Info.Printf("start to move file src: %s to dist: %s", src, dist)
	if err = util.CopyFile(src, dist); err != nil {
		return err
	}
	logger.Info.Printf("copyed to file src: %s to dist: %s", src, dist)
	if err = util.RemoveFile(src); err != nil {
		return err
	}
	logger.Info.Printf("remove to file: %s", src)
	return nil
}
