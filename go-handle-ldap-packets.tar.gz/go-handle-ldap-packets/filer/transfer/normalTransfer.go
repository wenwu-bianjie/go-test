package transfer

import (
	"errors"
	"fmt"
	"go-handle-ldap-packets/logger"
	"go-handle-ldap-packets/util"
	"time"
)

type NormalTransfer struct {
	distDir        string
	currentDatedir string // 使用时间点（年月日时创建目录）
}

func NewNormalTransfer(disDir string) (*NormalTransfer, error) {
	var (
		dir string
		err error
	)
	if disDir == "" {
		return nil, errors.New("normal_dir can not be empty")
	}
	dir = util.ReplacePathSeparator(disDir)
	err = util.CreateDir(dir)
	if err != nil {
		return nil, fmt.Errorf("create normal_dir with error: %s", err)
	}
	return &NormalTransfer{
		distDir: dir,
	}, nil
}

func (t *NormalTransfer) Move(src string) error {
	var (
		fileName string
		dist     string
		err      error
	)
	// 按时间创建转移目录
	t.createDirWithTime()
	if fileName, err = util.PathToFileName(src); err != nil {
		return err
	}
	dist = util.ComputeFilePath(util.ComputeFilePath(t.distDir, t.currentDatedir), fileName)
	logger.Info.Printf("start to move file src: %s to dist: %s", src, dist)
	if err = util.CopyFile(src, dist); err != nil {
		return err
	}
	logger.Info.Printf("copyed to file src: %s to dist: %s", src, dist)
	if err = util.RemoveFile(src); err != nil {
		return err
	}
	logger.Info.Printf("remove to file: %s", src)
	return nil
}

func (t *NormalTransfer) createDirWithTime() {
	var (
		date string
		dir  string
		err  error
	)
	// 将日期转为年月日时格式
	date = time.Now().Format("2006010215")
	// 如果当前时间目录不存在，则新建目录
	if t.currentDatedir != date {
		dir = util.ComputeFilePath(t.distDir, date)
		if err = util.CreateDir(dir); err != nil {
			logger.Error.Printf("create normal_dir children dir %s with error: %s", date, err)
		} else {
			t.currentDatedir = date
		}
	}
}
