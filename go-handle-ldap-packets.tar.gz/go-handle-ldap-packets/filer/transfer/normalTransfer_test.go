package transfer

import (
	"fmt"
	"testing"
	"time"
)

func TestNewNormalTransfer(t *testing.T) {
	date := time.Now().Format("2006010215")
	fmt.Println(date)
}
