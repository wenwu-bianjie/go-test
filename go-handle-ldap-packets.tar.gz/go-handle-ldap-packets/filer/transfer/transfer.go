package transfer

type Transfer interface {
	Move(src string) error
}
