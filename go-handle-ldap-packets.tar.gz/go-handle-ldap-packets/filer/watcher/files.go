package watcher

type fileInfo struct {
	name            string
	createOrModTime int64
}

type filesInfo []fileInfo

func (f filesInfo) Len() int {
	return len(f)
}

func (f filesInfo) Swap(i, j int) {
	f[i], f[j] = f[j], f[i]
}

func (f filesInfo) Less(i, j int) bool {
	return f[i].createOrModTime < f[j].createOrModTime
}
