package watcher

import (
	"fmt"
	"github.com/fsnotify/fsnotify"
	"go-handle-ldap-packets/config"
	"go-handle-ldap-packets/logger"
	"go-handle-ldap-packets/model"
	"go-handle-ldap-packets/util"
	"sort"
	"time"
)

type Watcher struct {
	w     *fsnotify.Watcher
	wDirs []string
	wChan chan string
}

func NewWatcher() (*Watcher, error) {
	var (
		w   *fsnotify.Watcher
		err error
	)
	//创建一个监控对象
	w, err = fsnotify.NewWatcher()
	if err != nil {
		return nil, fmt.Errorf("create watcher with error: %s", err)
	}
	return &Watcher{
		w:     w,
		wChan: make(chan string, 100),
	}, nil
}

func (w *Watcher) AddAndWatch(dirStr string) error {
	var (
		err         error
		dirs        []string
		dirTransfer string
	)
	dirs = util.StringsSplit(dirStr, ",")
	for _, dir := range dirs {
		dirTransfer = util.ReplacePathSeparator(util.Trim(dir))
		w.wDirs = append(w.wDirs, dirTransfer)
		if err = w.w.Add(dirTransfer); err != nil {
			return fmt.Errorf("watch dir: %s in err: %s", dir, err)
		}
	}
	go w.watch()
	return nil
}

func (w *Watcher) watch() {
	var (
		dir, fileName    string
		err              error
		watchDirsTimeout int64
		wdTimeout        time.Duration
	)
	watchDirsTimeout = config.G_config.WatchDirsTimeout
	// 不能设置为0，且必须大于5
	if watchDirsTimeout < model.MIN_WATCH_DIRS_TIMEOUT {
		watchDirsTimeout = model.MIN_WATCH_DIRS_TIMEOUT
	}
	// 转换为时间间隔类型
	wdTimeout = time.Duration(watchDirsTimeout)
	// 先进行旧文件检查
	w.checkWDirs()
	// 监控文件夹变化
	for {
		select {
		case ev := <-w.w.Events:
			{
				//判断事件发生的类型，如下5种
				// Create 创建
				if ev.Op&fsnotify.Create == fsnotify.Create {
					if dir, fileName, err = util.PathToDirAndFileName(ev.Name); err != nil {
						logger.Error.Printf("path %s To dir&fileame with error: %s", ev.Name, err)
					} else {
						w.sendCanParseFile(dir, fileName)
					}
				}
			}
		case <-time.After(time.Second * wdTimeout): // 若在一定的时间间隔内，没有新文件产生。则会去遍历文件夹中余下的文件
			go w.checkWDirs()
		}
	}
}

func (w *Watcher) checkWDirs() {
	var (
		exitFilesInfo filesInfo
		now           int64
	)
	now = time.Now().Unix()
	for _, d := range w.wDirs {
		if files, err := util.GetFilesFromDir(d); err == nil {
			for _, fileName := range files {
				if modTime, err := util.GetFileModTime(fileName); err == nil {
					// 观察60秒内未修改的文件
					if now-modTime > config.G_config.FilesModTimeToNowTime {
						exitFilesInfo = append(exitFilesInfo, fileInfo{name: fileName, createOrModTime: modTime})
					}
				} else {
					logger.Error.Printf("get file %s modTime  with error: %s", fileName, err)
				}
			}
		} else {
			logger.Error.Printf("get files from dir %s with error: %s", d, err)
		}
	}
	// 对匹配到的文件按照修改时间排序
	sort.Sort(exitFilesInfo)
	for _, f := range exitFilesInfo {
		w.wChan <- f.name
	}
}

func (w *Watcher) sendCanParseFile(dir, fileName string) {
	var (
		exitFilesInfo filesInfo
	)
	for _, d := range w.wDirs {
		if util.StrContain(d, dir) {
			newestFilePath := util.ComputeFilePath(d, fileName)
			if newestFileCreateTime, err := util.GetFileCreateTime(newestFilePath); err == nil {
				if files, err := util.GetFilesFromDir(d); err == nil {
					if len(files) < 2 {
						return
					}
					for _, fileName := range files {
						if fileName == newestFilePath {
							continue
						}
						if createTime, err := util.GetFileCreateTime(fileName); err == nil {
							if createTime < newestFileCreateTime {
								exitFilesInfo = append(exitFilesInfo, fileInfo{name: fileName, createOrModTime: createTime})
							}
						} else {
							logger.Error.Printf("get file %s createTime  with error: %s", fileName, err)
						}
					}
				} else {
					logger.Error.Printf("get files from dir %s with error: %s", d, err)
				}
			} else {
				logger.Error.Printf("get file %s createTime  with error: %s", newestFilePath, err)
			}
		}
	}
	// 对匹配到的文件按照创建时间排序
	sort.Sort(exitFilesInfo)
	for _, f := range exitFilesInfo {
		w.wChan <- f.name
	}
}

func (w *Watcher) GetWChan() chan string {
	return w.wChan
}

func (w *Watcher) Close() {
	if w.w != nil {
		w.w.Close()
	}
}
