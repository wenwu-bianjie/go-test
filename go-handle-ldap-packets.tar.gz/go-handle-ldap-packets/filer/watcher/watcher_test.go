package watcher

import (
	"fmt"
	"testing"
	"time"
)

func TestNewWatcher(t *testing.T) {
	a := []int{1, 2, 3}
	fmt.Println(a)
	a = a[1:]
	c := time.After(1 * time.Second)
	for {
		select {
		case <-c:
			fmt.Println("after 1 second")
			continue
		case <-time.After(5 * time.Second):
			fmt.Println("after 5 second")
			break
		}
	}
}
