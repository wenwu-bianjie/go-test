package config

import (
	"encoding/json"
	"errors"
	"flag"
	"go-handle-ldap-packets/model"
	"go-handle-ldap-packets/util"
	"io/ioutil"
	"log"
)

type config struct {
	WatchDirs             string               `json:"watch_dirs"`
	NormalDir             string               `json:"normal_dir"`
	AbnormalDir           string               `json:"abnormal_dir"`
	MatchFields           string               `json:"match_fields"`
	LogDir                string               `json:"log_dir"`
	LogLevel              string               `json:"log_level"`
	WatchDirsTimeout      int64                `json:"watch_dirs_timeout"`
	FilesModTimeToNowTime int64                `json:"files_mod_time_to_now_time"`
	CmdFilePath           string               `json:"cmd_file_path"`
	WarnParameters        model.WarnParameters `json:"warn_parameters"`
}

var (
	confFile string // 配置文件路径
	G_config *config
)

func init() {
	var err error
	// 初始化命令行参数
	initArgs()
	// 加载配置
	if err = initConfig(confFile); err != nil {
		log.Fatalf("init args with error: %s", err)
	}
}

// 解析命令行参数
func initArgs() {
	flag.StringVar(&confFile, "config", "./config.json", "指定config.json")
	flag.Parse()
}

func initConfig(fileName string) error {
	var (
		content      []byte
		conf         config
		err          error
		confFileName string
	)
	// 配置文件路径不能为空
	if fileName == "" {
		return errors.New("config file can not be empty")
	}
	// 转换配置文件路径
	confFileName = util.ReplacePathSeparator(util.Trim(fileName))
	// 把配置文件读进来
	if content, err = ioutil.ReadFile(confFileName); err != nil {
		return err
	}
	// 做JSON反序列化
	if err = json.Unmarshal(content, &conf); err != nil {
		return err
	}
	// 赋值单例
	G_config = &conf
	return nil
}
