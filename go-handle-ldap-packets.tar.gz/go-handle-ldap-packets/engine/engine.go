package engine

import (
	"go-handle-ldap-packets/config"
	"go-handle-ldap-packets/filer/transfer"
	"go-handle-ldap-packets/filer/watcher"
	"go-handle-ldap-packets/logger"
	"go-handle-ldap-packets/model"
	"go-handle-ldap-packets/parser/analyzer"
	"go-handle-ldap-packets/util"
	"os"
	"os/signal"
)

type Engine struct {
	dirsWatcher      *watcher.Watcher
	parser           *analyzer.Analyzer
	normalTransfer   transfer.Transfer
	abnormalTransfer transfer.Transfer
}

func NewEngine() (*Engine, error) {
	var (
		err                              error
		dirsWatcher                      *watcher.Watcher
		parser                           *analyzer.Analyzer
		normalTransfer, abnormalTransfer transfer.Transfer
	)
	// 新建watcher监控文件夹变化
	if dirsWatcher, err = watcher.NewWatcher(); err != nil {
		return nil, err
	}

	logger.Info.Println("create dir watcher")

	// 新建解析对象
	parser = analyzer.NewAnalyzer()

	logger.Info.Println("create packet parser")

	// 创建未命中转移对象
	if normalTransfer, err = transfer.NewNormalTransfer(config.G_config.NormalDir); err != nil {
		return nil, err
	}
	// 创建命中转移对象
	if abnormalTransfer, err = transfer.NewAbnormalTransfer(config.G_config.AbnormalDir); err != nil {
		return nil, err
	}

	logger.Info.Println("create file transfer")

	return &Engine{
		dirsWatcher:      dirsWatcher,
		parser:           parser,
		normalTransfer:   normalTransfer,
		abnormalTransfer: abnormalTransfer,
	}, nil
}

// 开始启动
func (e *Engine) Run() error {
	var (
		dirsWatcherChan  chan string
		parserChan       chan string
		fileMovedChan    chan string
		fileParseResChan chan *model.FileParseRes
		err              error
	)
	// 添加监控目录并启动监控
	if err = e.dirsWatcher.AddAndWatch(config.G_config.WatchDirs); err != nil {
		return err
	}
	// 启动解析器
	e.parser.Run()

	dirsWatcherChan = e.dirsWatcher.GetWChan()
	parserChan = e.parser.GetFileChan()
	fileMovedChan = e.parser.GetFileMovedChan()
	fileParseResChan = e.parser.GetFileParseResChan()

	// 监测程序是否被关闭
	e.watch()
	// 程序关闭时释放资源
	defer e.stop()

	// 服务启动
	logger.Info.Println("engine is running")

	for {
		select {
		case file := <-dirsWatcherChan:
			// 将监控的文件路径发给解析器
			logger.Info.Printf("start to parse file: %s", file)
			parserChan <- file
		case res := <-fileParseResChan:
			// 根据结果将文件转移到不同的文件夹
			if res.IsMatched {
				err = e.abnormalTransfer.Move(res.FileName)
			} else {
				err = e.normalTransfer.Move(res.FileName)
			}
			if err != nil {
				logger.Error.Printf("tranfer file %s with error: %s", res.FileName, err)
			} else {
				logger.Info.Printf("moved file: %s", res.FileName)
				fileMovedChan <- res.FileName
			}
		}
	}
	return nil
}

// 观察程序运行情况
func (e *Engine) watch() {
	var (
		signals chan os.Signal
	)
	// 监控程序被杀，释放资源
	go func() {
		signals = make(chan os.Signal, 1)
		signal.Notify(signals, os.Kill, os.Interrupt)
		<-signals
		e.stop()
	}()
}

// 暂停
func (e *Engine) stop() {
	logger.CloseLogFile()
	// 关闭监控
	e.dirsWatcher.Close()
	// 关闭正在解析的文件
	e.parser.Close()
	// 关闭正在读写的文件
	util.CloseFileWhenProcessKill()
}
