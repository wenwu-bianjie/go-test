package logger

import (
	"fmt"
	"go-handle-ldap-packets/config"
	"go-handle-ldap-packets/model"
	"go-handle-ldap-packets/util"
	"io"
	"log"
	"os"
)

var (
	Info  *logger
	Error *logger

	logFiles []*os.File
	// 日志等级
	logLevel []string
	// 日志的根目录
	logRootDir string
	// 当前日志文件日期
	logFileDate string
)

const (
	LOG_TYPE_INFO_NAME  = "info"
	LOG_TYPE_ERROR_NAME = "error"
)

func init() {
	// 初始化日志等级
	logLevel = initLogLevel()
	// 初始化日志根目录
	initLogRootDir()
	// 根据日志等级创建日志文件
	// 计算当前日期
	date := util.GetCurrentDateStr()
	// 根据当前时间，生产日志文件日期
	if logFileDate != date {
		logFileDate = date
	}
	createLogFiles()
}

// 初始化日志等级
func initLogLevel() []string {
	var logLevel []string
	switch config.G_config.LogLevel {
	case LOG_TYPE_INFO_NAME:
		logLevel = []string{LOG_TYPE_INFO_NAME, LOG_TYPE_ERROR_NAME}
	case LOG_TYPE_ERROR_NAME:
		logLevel = []string{LOG_TYPE_ERROR_NAME}
	default:
		logLevel = []string{LOG_TYPE_INFO_NAME, LOG_TYPE_ERROR_NAME}
	}
	return logLevel
}

// 创建日志目录
func initLogRootDir() {
	logRootDir = util.Trim(config.G_config.LogDir)
	// 如果日志目录为空，则使用默认值
	if logRootDir == "" {
		logRootDir = model.LOG_DIR
	}
	// 转换日志目录
	logRootDir = util.ReplacePathSeparator(logRootDir)
}

func createLogFiles() {
	var (
		logDir      string
		err         error
		newLogFiles []*os.File
	)
	for _, level := range logLevel {
		logDir = util.ComputeFilePath(logRootDir, level)
		err = util.CreateDir(logDir)
		if err != nil {
			log.Fatalf("create logs dir %s with error: %s", logDir, err)
		} else {
			logfile := createLogFile(logDir, level)
			newLogFiles = append(newLogFiles, logfile)
		}
	}
	// 关闭之前的文件
	if len(logFiles) > 0 {
		CloseLogFile()
	}
	logFiles = newLogFiles
}

// 创建日志文件
func createLogFile(logDir, level string) *os.File {
	var (
		fileName string
		logfile  *os.File
		err      error
	)
	// 计算日志文件路径
	fileName = util.ComputeFilePath(logDir, fmt.Sprintf("%s-%s.log", logFileDate, level))
	// 创建正常日志文件
	logfile, err = os.OpenFile(fileName, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
	if err != nil {
		log.Fatalf("create log file %s with error: %s", fileName, err)
	}
	logLevelWrite(level, logfile)
	return logfile
}

func logLevelWrite(level string, logfile *os.File) {
	// 根据不同等级输出日志
	switch level {
	case LOG_TYPE_INFO_NAME:
		Info = &logger{
			log: log.New(io.Writer(logfile), "Info:", log.Ldate|log.Ltime|log.Lshortfile),
		}
	case LOG_TYPE_ERROR_NAME:
		Error = &logger{
			log: log.New(io.Writer(logfile), "Error:", log.Ldate|log.Ltime|log.Lshortfile),
		}
	}
}

func CloseLogFile() {
	var err error
	for _, f := range logFiles {
		if f != nil {
			if err = f.Close(); err != nil {
				Error.Println(err)
			}
		}
	}
}
