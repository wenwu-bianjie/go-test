package logger

import (
	"go-handle-ldap-packets/util"
	"log"
)

// 自定义日志对象
type logger struct {
	log *log.Logger
}

func (l *logger) Printf(format string, v ...interface{}) {
	if l == nil {
		return
	}
	l.log.Printf(format, v)
	l.checkCurrentDate()
}

func (l *logger) Println(v ...interface{}) {
	if l == nil {
		return
	}
	l.log.Println(v)
	l.checkCurrentDate()
}

func (l *logger) checkCurrentDate() {
	date := util.GetCurrentDateStr()
	if logFileDate != date {
		// 新建日志文件，和输出
		logFileDate = date
		createLogFiles()
	}
}
