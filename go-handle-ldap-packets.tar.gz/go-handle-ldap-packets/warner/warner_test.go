package warner

import (
	"testing"
)

func TestNewWarner(t *testing.T) {
	w := NewWarner("./ump_udp_c.dat")
	w.Send()
}
