package warner

import (
	"fmt"
	"go-handle-ldap-packets/config"
	"go-handle-ldap-packets/logger"
	"go-handle-ldap-packets/model"
	"go-handle-ldap-packets/util"
	"os/exec"
)

type Warner struct {
	CmdFilePath    string
	warnParameters *model.WarnParameters
}

func (w *Warner) Send() {
	var (
		cmd    *exec.Cmd
		output []byte
		err    error
	)
	cmd = exec.Command(
		w.CmdFilePath,
		w.warnParameters.SendIp,
		w.warnParameters.SendPort,
		w.warnParameters.EventType,
		w.warnParameters.EventSt,
		util.NewUuid(),
		w.warnParameters.System,
		w.warnParameters.Component,
		w.warnParameters.Item,
		w.warnParameters.ObjId,
		w.warnParameters.LocationId,
		w.warnParameters.Severity,
		w.warnParameters.EventCode,
		util.GetCurrentTimeStampStr(),
		w.warnParameters.Msg,
		w.warnParameters.MsgAddn,
		w.warnParameters.Resv,
	)
	output, err = cmd.Output()
	if err != nil {
		logger.Error.Printf("execute file: %s failed with error: %s", cmd, err.Error())
		return
	}
	logger.Info.Printf("execute file: %s finished with output:\n%s", cmd, string(output))
}

func NewWarner(path string) (*Warner, error) {
	var (
		cmdFile string
	)
	cmdFile = util.Trim(path)
	if cmdFile == "" {
		return nil, fmt.Errorf("cmd_file_path can not be empty")
	}
	cmdFile = util.ReplacePathSeparator(cmdFile)
	if err := util.ForFileCanExec(cmdFile); err != nil {
		return nil, err
	}
	return &Warner{
		CmdFilePath: cmdFile,
		warnParameters: &model.WarnParameters{
			SendIp:     string(util.Utf8ToGbk(config.G_config.WarnParameters.SendIp)),
			SendPort:   string(util.Utf8ToGbk(config.G_config.WarnParameters.SendPort)),
			EventType:  string(util.Utf8ToGbk(config.G_config.WarnParameters.EventType)),
			EventSt:    string(util.Utf8ToGbk(config.G_config.WarnParameters.EventSt)),
			EventId:    string(util.Utf8ToGbk(config.G_config.WarnParameters.EventId)),
			System:     string(util.Utf8ToGbk(config.G_config.WarnParameters.System)),
			Component:  string(util.Utf8ToGbk(config.G_config.WarnParameters.Component)),
			Item:       string(util.Utf8ToGbk(config.G_config.WarnParameters.Item)),
			ObjId:      string(util.Utf8ToGbk(config.G_config.WarnParameters.ObjId)),
			LocationId: string(util.Utf8ToGbk(config.G_config.WarnParameters.LocationId)),
			Severity:   string(util.Utf8ToGbk(config.G_config.WarnParameters.Severity)),
			EventCode:  string(util.Utf8ToGbk(config.G_config.WarnParameters.EventCode)),
			TimeStamp:  string(util.Utf8ToGbk(config.G_config.WarnParameters.TimeStamp)),
			Msg:        string(util.Utf8ToGbk(config.G_config.WarnParameters.Msg)),
			MsgAddn:    string(util.Utf8ToGbk(config.G_config.WarnParameters.MsgAddn)),
			Resv:       string(util.Utf8ToGbk(config.G_config.WarnParameters.Resv)),
		},
	}, nil
}
