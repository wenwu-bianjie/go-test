package main

import (
	_ "go-handle-ldap-packets/config"
	"go-handle-ldap-packets/engine"
	_ "go-handle-ldap-packets/logger"
	"log"
	"runtime"
)

func main() {
	var (
		err          error
		simpleEngine *engine.Engine
	)
	// 设置并发数为内核数
	runtime.GOMAXPROCS(runtime.NumCPU())
	// 新建simpleEngine
	if simpleEngine, err = engine.NewEngine(); err != nil {
		goto ERR
	}
	// 启动simpleEngine
	if err = simpleEngine.Run(); err != nil {
		goto ERR
	}
	return
ERR:
	log.Printf("start with error: %s", err)
}
