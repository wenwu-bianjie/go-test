package model

// 告警参数
type WarnParameters struct {
	SendIp     string `json:"send_ip"`
	SendPort   string `json:"send_port"`
	EventType  string `json:"event_type"`
	EventSt    string `json:"event_st"`
	EventId    string `json:"event_id"`
	System     string `json:"system"`
	Component  string `json:"component"`
	Item       string `json:"item"`
	ObjId      string `json:"obj_id"`
	LocationId string `json:"location_id"`
	Severity   string `json:"severity"`
	EventCode  string `json:"event_code"`
	TimeStamp  string `json:"time_stamp"`
	Msg        string `json:"msg"`
	MsgAddn    string `json:"msg_addn"`
	Resv       string `json:"resv"`
}
