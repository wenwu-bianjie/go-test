package model

import "os"

const PTH_SEP = string(os.PathSeparator)

// 日志文件目录
const LOG_DIR string = "./logs"

const MIN_WATCH_DIRS_TIMEOUT int64 = 10
