package model

type ParsedData struct {
	CaptureFilename string   `json:"capture_filename"`
	Frame           int64    `json:"frame"`
	Time            string   `json:"time"`
	FrameBytes      int      `json:"frame_bytes"`
	SrcMAC          string   `json:"src_mac"`
	DstMAC          string   `json:"dst_mac"`
	SrcIP           string   `json:"src_ip"`
	DstIP           string   `json:"dst_ip"`
	SrcIpv6         string   `json:"src_ipv6"`
	DstIpv6         string   `json:"dst_ipv6"`
	SrcPort         string   `json:"src_port"`
	DstPort         string   `json:"dst_port"`
	IPVersion       string   `json:"ip_version"`
	TCPFlags        TCPFlags `json:"tcp_flags"`
	Identification  uint16   `json:"identification"`
	Seq             uint32   `json:"seq"`
	Ack             uint32   `json:"ack"`
	PayloadBytes    int      `json:"payload_bytes"`
	Payload         string   `json:"payload"`
	SysName         string   `json:"sys_name"`
}

type TCPFlags struct {
	FIN bool `json:"FIN"`
	SYN bool `json:"SYN"`
	RST bool `json:"RST"`
	PSH bool `json:"PSH"`
	ACK bool `json:"ACK"`
	URG bool `json:"URG"`
	ECE bool `json:"ECE"`
	CWR bool `json:"CWR"`
	NS  bool `json:"NS"`
}

// 解析及匹配完成结果
type FileParseRes struct {
	FileName  string
	IsMatched bool
}
