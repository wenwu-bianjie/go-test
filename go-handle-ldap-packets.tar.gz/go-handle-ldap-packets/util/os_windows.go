package util

import (
	"os"
	"runtime"
	"syscall"
	"time"
)

func GetFileCreateTime(path string) (int64, error) {
	osType := runtime.GOOS
	fileInfo, err := os.Stat(path)
	if err != nil {
		return 0, err
	}
	if osType == "windows" {
		wFileSys := fileInfo.Sys().(*syscall.Win32FileAttributeData)
		tNanSeconds := wFileSys.CreationTime.Nanoseconds() /// 返回的是纳秒
		tSec := tNanSeconds / 1e9                          ///秒
		return tSec, nil
	}
	return time.Now().Unix(), nil
}
