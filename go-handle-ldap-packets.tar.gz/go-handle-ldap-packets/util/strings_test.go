package util

import (
	"fmt"
	"testing"
)

func TestStringsSplit(t *testing.T) {
	dir, fileName, _ := PathToDirAndFileName("\\a\\b\\c.pcap")
	fmt.Println(dir, fileName)
}
