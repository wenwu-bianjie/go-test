package util

import (
	"fmt"
	"testing"
)

func TestNewUuid(t *testing.T) {
	u := NewUuid()
	fmt.Println(u)
}
