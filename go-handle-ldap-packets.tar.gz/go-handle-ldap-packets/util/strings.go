package util

import (
	"bufio"
	"bytes"
	"go-handle-ldap-packets/model"
	"golang.org/x/text/encoding/simplifiedchinese"
	"io/ioutil"

	//"io/ioutil"
	"golang.org/x/net/html/charset"
	"golang.org/x/text/encoding"
	"golang.org/x/text/encoding/unicode"
	"golang.org/x/text/transform"
	"strings"
	"time"
)

// 通过sep切分字符串
func StringsSplit(str string, sep string) []string {
	return strings.SplitN(str, sep, -1)
}

// 将目录路径中的文件路径及名称提取出来
func PathToDirAndFileName(path string) (string, string, error) {
	var err error
	var dir bytes.Buffer
	arr := StringsSplit(path, model.PTH_SEP)
	l := len(arr) - 1
	i := 0
	for {
		if _, err = dir.WriteString(arr[i]); err != nil {
			return "", "", err
		}
		i++
		if i < l {
			if _, err = dir.WriteString(model.PTH_SEP); err != nil {
				return "", "", err
			}
		} else {
			break
		}
	}
	return dir.String(), arr[l], nil
}

func PathToFileName(path string) (string, error) {
	arr := StringsSplit(path, model.PTH_SEP)
	l := len(arr) - 1
	return arr[l], nil
}

func StrContain(longStr string, shortStr string) bool {
	return strings.Contains(longStr, shortStr)
}

// 更换路径分割符
func ReplacePathSeparator(dirPath string) string {
	return strings.ReplaceAll(dirPath, "/", model.PTH_SEP)
}

// 去除字符串两端的空格
func Trim(str string) string {
	return strings.Trim(str, " ")
}

// 获取当前日期字符串
func GetCurrentDateStr() string {
	return time.Now().Format("20060102")
}

// 获取当前日期字符串
func GetCurrentTimeStampStr() string {
	return time.Now().Format("2006-01-02 15:04:05")
}

func strEncodingToUtf8(str string) []byte {
	reader := strings.NewReader(str)
	strReader := bufio.NewReader(reader)
	e := determineEncoding(strReader)
	utf8Reader := transform.NewReader(strReader,
		e.NewDecoder())
	if b, err := ioutil.ReadAll(utf8Reader); err != nil {
		return nil
	} else {
		return b
	}
}

func Utf8ToGbk(s string) []byte {
	strUtf8 := strEncodingToUtf8(s)
	reader := transform.NewReader(bytes.NewReader(strUtf8), simplifiedchinese.GBK.NewEncoder())
	if d, err := ioutil.ReadAll(reader); err != nil {
		return nil
	} else {
		return d
	}
}

// 转换编码格式为utf8
func determineEncoding(r *bufio.Reader) encoding.Encoding {
	bytes, err := r.Peek(1024)
	if err != nil {
		return unicode.UTF8
	}
	e, _, _ := charset.DetermineEncoding(
		bytes, "")
	return e
}
