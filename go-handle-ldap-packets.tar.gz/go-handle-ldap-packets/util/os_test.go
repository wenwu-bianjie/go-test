package util

import (
	"fmt"
	"os"
	"testing"
	"time"
)

func TestGetFilesFromDir(t *testing.T) {
	dir := fmt.Sprintf("..%spcapDir", string(os.PathSeparator))
	files, err := GetFilesFromDir(dir)
	if err != nil {
		t.Errorf("fail to GetFilesFromDir: %s", err)
		return
	}
	fmt.Println(files)
}

func TestCopyFile(t *testing.T) {
	t1 := time.Now().Nanosecond()
	CopyFile("./test/spnew01ljo01_20200420135958.pcap", "./distTest/a.pcap")
	t2 := time.Now().Nanosecond()
	fmt.Println(t2 - t1)
}

func TestWithoutBuffCopyFile(t *testing.T) {
	t1 := time.Now().Nanosecond()
	WithoutBuffCopyFile("./test/spnew01ljo01_20200420135958.pcap", "./distTest/b.pcap")
	t2 := time.Now().Nanosecond()
	fmt.Println(t2 - t1)
}

func TestRemoveFile(t *testing.T) {
	RemoveFile("./test/spnew01ljo01_20200420135958.pcap")
}

func TestCreateDir(t *testing.T) {
	CreateDir("./test/b")
}
