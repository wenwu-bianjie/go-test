// +build !windows

package util

import (
	"os"
	"runtime"
	"syscall"
	"time"
)

func GetFileCreateTime(path string) (int64, error) {
	osType := runtime.GOOS
	fileInfo, err := os.Stat(path)
	if err != nil {
		return 0, err
	}
	if osType == "linux" {
		stat_t := fileInfo.Sys().(*syscall.Stat_t)
		tCreate := int64(stat_t.Ctim.Sec)
		return tCreate, nil
	}
	return time.Now().Unix(), nil
}
