package util

import (
	"fmt"
	"go-handle-ldap-packets/model"
	"io"
	"io/ioutil"
	"os"
	"strings"
	"time"
)

// 查看文件是否存在
func PathExists(path string) (bool, error) {
	_, err := os.Stat(path)
	if err == nil {
		return true, nil
	}
	if os.IsNotExist(err) {
		return false, nil
	}
	return false, err
}

//获取指定目录下的所有文件和目录
func GetFilesFromDir(dirPth string) (files []string, err error) {
	dir, err := ioutil.ReadDir(dirPth)
	isLastPthSep := strings.LastIndex(dirPth, model.PTH_SEP) == len(dirPth)-1
	if err != nil {
		return nil, err
	}
	//suffix = strings.ToUpper(suffix) //忽略后缀匹配的大小写
	for _, fi := range dir {
		if fi.IsDir() == false { // 目录, 递归遍历
			// 过滤指定文件后缀
			ok := strings.HasSuffix(fi.Name(), ".pcap")
			if ok {
				var dirPath string = ""
				if isLastPthSep {
					dirPath = fmt.Sprintf("%s%s", dirPth, fi.Name())
				} else {
					dirPath = fmt.Sprintf("%s%s%s", dirPth, model.PTH_SEP, fi.Name())
				}
				if dirPath != "" {
					files = append(files, dirPath)
				}
			}
		}
	}
	return files, nil
}

func ComputeFilePath(dir, fileName string) string {
	isLastPthSep := strings.LastIndex(dir, model.PTH_SEP) == len(dir)-1
	if isLastPthSep {
		return fmt.Sprintf("%s%s", dir, fileName)
	} else {
		return fmt.Sprintf("%s%s%s", dir, model.PTH_SEP, fileName)
	}
}

func GetFileModTime(path string) (int64, error) {
	file, err := os.Stat(path)
	if err != nil {
		return time.Now().Unix(), err
	}
	if err != nil {
		return time.Now().Unix(), err
	}
	return file.ModTime().Unix(), nil
}

// 不使用buffer复制文件
func WithoutBuffCopyFile(srcName, dstName string) (written int64, err error) {
	src, err := os.Open(srcName)
	if err != nil {
		return
	}
	defer src.Close()
	dst, err := os.OpenFile(dstName, os.O_WRONLY|os.O_CREATE, 0644)
	if err != nil {
		return
	}
	defer dst.Close()
	return io.Copy(dst, src)
}

// 使用buffer复制文件到
var copyBuf []byte = make([]byte, 1024*1024)

// 暴露出来用于程序被杀时关闭文件句柄
var Destination *os.File
var Source *os.File

func CopyFile(srcName, dstName string) error {
	var err error
	Source, err = os.Open(srcName)
	if err != nil {
		return err
	}
	defer func() {
		Source.Close()
		Source = nil
	}()

	Destination, err = os.OpenFile(dstName, os.O_WRONLY|os.O_CREATE, 0644)
	if err != nil {
		return err
	}
	defer func() {
		Destination.Close()
		Destination = nil
	}()

	for {
		n, err := Source.Read(copyBuf)
		if err != nil && err != io.EOF {
			return err
		}
		if n == 0 {
			break
		}
		if _, err = Destination.Write(copyBuf[:n]); err != nil {
			return err
		}
	}
	return nil
}

// 关闭文件句柄
func CloseFileWhenProcessKill() {
	if Source != nil {
		Source.Close()
	}
	if Destination != nil {
		Destination.Close()
	}
}

// 删除文件
func RemoveFile(file string) error {
	err := os.Remove(file)
	return err
}

// 创建文件夹
func CreateDir(dir string) error {
	var (
		err error
	)
	if _, err = os.Stat(dir); os.IsNotExist(err) {
		// 必须分成两步：先创建文件夹、再修改权限
		if err = os.MkdirAll(dir, os.ModePerm); err != nil { //0777也可以os.ModePerm
			return err
		}
	}
	err = os.Chmod(dir, os.ModePerm)
	return err
}

// 给文件执行权限
func ForFileCanExec(file string) error {
	err := os.Chmod(file, os.ModePerm)
	return err
}
